from functools import lru_cache

graph = [
    [0, 10, 15, 20],
    [10, 0, 35, 25],
    [15, 35, 0, 30],
    [20, 25, 30, 0]
]

n = len(graph)

@lru_cache(None)
def tsp(mask, pos):
    if mask == (1 << n) - 1:
        return graph[pos][0]

    ans = float("inf")

    for city in range(n):
        if not mask & (1 << city):
            ans = min(
                ans,
                graph[pos][city] +
                tsp(mask | (1 << city), city)
            )

    return ans


print("Minimum Cost =", tsp(1, 0))
